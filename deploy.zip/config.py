EMAIL= "rfq@procucev.com"
APP_PASSWORD ="djds biac asvw ppwq"

# EMAIL= "veerababu.v@procucev.com"
# APP_PASSWORD ="coqt ewiy etst deke"